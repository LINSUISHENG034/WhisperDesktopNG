import SwiftUI

@main
struct WhisperCppDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
